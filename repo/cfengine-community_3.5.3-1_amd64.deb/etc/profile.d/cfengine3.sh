export PATH=$PATH:/var/cfengine/bin
export MANPATH=$MANPATH:/var/cfengine/share/man
