APP_PATH='/usr/share/ocemr/apps/ocemr'
SOURCE_TEMPLATE='engeye'
VIEWER_PASSWORD='changeme'
